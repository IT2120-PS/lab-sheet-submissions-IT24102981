setwd("C:\\Users\\IT24102981\\Desktop\\IT24102981")

#import the dataset
data<-read.table("Exercise - LaptopsWeights.txt", header =TRUE)
fix(data)
attach(data)

#Q1
#calculate population mean and standard deviation
popmn<-mean(Weight.kg.)
popmn
popvar<- var(Weight.kg.)
popsd<-sd(Weight.kg.)
popsd

# Q2
#store sample data
samples<-c()
names<-c()

#create and assign samples
for(i in 1:25){
  s<-sample(Weight.kg.,6,replace=TRUE)
  samples<-cbind(samples,s)
  names<-c(names,paste('S',i))
}

#assign column names for the sample created
colnames(samples)<-names

#calculate sample mean and standard deviation column wise which was stored in samples
s.means<-apply(samples,2,mean)
s.means

s.sd<-apply(samples,2,sd)
s.sd

#Q3
#true mean and true standard deviation
mean<- mean(s.means)
mean

sd <-sd(s.sd)
sd

#Calculate mean of 25 sample means
mean_sample_means<-mean(s.means)
mean_sample_means
sd_sample_means<-sd(s.means)
sd_sample_meansD

#compare the relationship
truesd=popsd/6
true_mean=popmn/6
true_mean
truesd
