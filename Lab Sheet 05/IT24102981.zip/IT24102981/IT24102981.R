setwd("C:\\Users\\IT24102981\\Desktop\\IT24102981")

#importing the data set
Delivery_Times<-read.table("C:\\Users\\IT24102981\\Desktop\\IT24102981\\Exercise - Lab 05.txt",header=TRUE,sep=" ")
attach(Delivery_Times)

#rename the column headings for easier use
names(Delivery_Times)<-c("X1")
attach(Delivery_Times)

#obtain histogram
hist(X1,main="Histogram for deliver times")
#histogram
histogram<- hist(X1,main="Histogram for deliver times",breaks=seq(20,70,length=10),right=FALSE)



#frequency distribution for the above histogram
#assigning class limits
breaks <-round(histogram$breaks)  
#assigning class frequencies
freq <-histogram$counts
#assigning mid point of each class
mids <-histogram$mids

#creating classes
classes <-c()

#assigning classes into the "classes" variable
for(i in 1:length(breaks)-1){
  classes[i]<-paste0("[",breaks[i],",", breaks[i+1],")")
}

#merge columns with same length
cbind(classes=classes,Frequency=freq)

#draw frequency polygon
lines(mids,freq)

#draw freq polygon in a new plot
plot(mids,freq,type='l',main='cumulative frequency polygon for delivery times',xlab ='delivery times',ylab='frequency',ylim=c(0,max(freq)))

#cumulative frequency polygon
cum.freq<- cumsum(freq)

new<-c()

#using for loop to store cumulative frequencies
for(i in 1:length(breaks)){
  if(i==1){
    new[i]=0
  }
  else{
    new[i]=cum.freq[i-1]
  }
}

#draw cumulative frequency polygon
plot(breaks,new,type='l',main='cumulative frequency polygon for delivery times',xlab='delivery times',ylab='cumulative frequency',ylim=c(0,max(cum.freq)))
